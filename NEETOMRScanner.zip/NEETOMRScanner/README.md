# NEET OMR Scanner

A complete Android app to scan answer keys and practice NEET exams.

## Features
- 📷 Scan answer key image (ML Kit OCR)
- 📝 Dynamic NEET-style OMR interface
- ⏱ Optional countdown timer
- 📊 Results with score, accuracy, green/red feedback
- 📁 Full test history with SQLite

## How to Build APK (Free, No PC needed)

### Option A — GitHub Actions (Recommended)
1. Create a free account at github.com
2. Create a **New Repository** (name it `NEETOMRScanner`)
3. Upload ALL files from this zip (maintain folder structure)
4. GitHub Actions will **automatically build** the APK
5. Go to **Actions → Build APK → latest run → Artifacts**
6. Download `NEET-OMR-Scanner-Debug.apk`

### Option B — Replit
1. Go to replit.com → New Repl → choose **Gradle**
2. Upload all files
3. Run: `gradle assembleDebug`
4. Download APK from `app/build/outputs/apk/debug/`

## NEET Scoring
- Correct answer: **+4 marks**
- Wrong answer: **-1 mark**
- Unattempted: **0 marks**
