package com.neet.omrscanner;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView title = findViewById(R.id.tvTitle);
        Button btnNew  = findViewById(R.id.btnNewTest);
        Button btnHist = findViewById(R.id.btnHistory);

        title.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        btnNew .startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        btnHist.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));

        btnNew .setOnClickListener(v -> startActivity(new Intent(this, ScanActivity.class)));
        btnHist.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
    }
}
