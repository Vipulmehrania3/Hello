package com.neet.omrscanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.neet.omrscanner.adapters.QuestionAdapter;
import com.neet.omrscanner.models.Question;
import com.neet.omrscanner.models.TestResult;
import com.neet.omrscanner.utils.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ResultActivity extends AppCompatActivity {

    @SuppressWarnings("unchecked")
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_result);

        List<Question> qs   = (List<Question>) getIntent().getSerializableExtra("questions");
        long           time = getIntent().getLongExtra("time_taken", 0);

        int total = qs.size(), correct = 0, wrong = 0, unatt = 0;
        for (Question q : qs) {
            if (q.isUnattempted()) unatt++;
            else if (q.isCorrect()) correct++;
            else wrong++;
        }
        int   score    = correct * 4 - wrong;
        int   maxScore = total * 4;
        float acc      = total > 0 ? correct * 100f / total : 0;

        // persist
        TestResult r = new TestResult();
        r.setDate(new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date()));
        r.setTotalQuestions(total); r.setCorrect(correct);
        r.setWrong(wrong); r.setUnattempted(unatt);
        r.setScore(score); r.setAccuracy(acc); r.setTimeTaken(time);
        new DatabaseHelper(this).insert(r);

        set(R.id.tvScore,       score + " / " + maxScore);
        set(R.id.tvAccuracy,    String.format("%.1f%% Accuracy", acc));
        set(R.id.tvCorrect,     String.valueOf(correct));
        set(R.id.tvWrong,       String.valueOf(wrong));
        set(R.id.tvUnattempted, String.valueOf(unatt));
        set(R.id.tvTotal,       String.valueOf(total));
        set(R.id.tvTimeTaken,   String.format("%02d:%02d", time/60, time%60));

        RecyclerView rv = findViewById(R.id.rvReview);
        QuestionAdapter a = new QuestionAdapter(this, qs);
        a.setResultMode(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(a);

        ((Button) findViewById(R.id.btnHome)).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
        });
        ((Button) findViewById(R.id.btnHistory)).setOnClickListener(v ->
            startActivity(new Intent(this, HistoryActivity.class)));
    }

    private void set(int id, String txt) { ((TextView) findViewById(id)).setText(txt); }

    @Override public void onBackPressed() {
        startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        finish();
    }
}
