package com.neet.omrscanner.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.neet.omrscanner.R;
import com.neet.omrscanner.models.TestResult;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.VH> {

    private final List<TestResult> data;
    private final Context          ctx;

    public HistoryAdapter(Context ctx, List<TestResult> data) { this.ctx = ctx; this.data = data; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(ctx).inflate(R.layout.item_history, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        TestResult r = data.get(pos);
        h.date.setText(r.getDate());
        h.score.setText("Score: " + r.getScore() + " / " + (r.getTotalQuestions()*4));
        h.acc.setText(String.format("%.1f%% accuracy", r.getAccuracy()));
        h.details.setText("✓ " + r.getCorrect() + "   ✗ " + r.getWrong() + "   — " + r.getUnattempted());
        long m = r.getTimeTaken()/60, s = r.getTimeTaken()%60;
        h.time.setText(String.format("⏱ %02d:%02d", m, s));
    }

    @Override public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView date, score, acc, details, time;
        VH(@NonNull View v) {
            super(v);
            date    = v.findViewById(R.id.tvDate);
            score   = v.findViewById(R.id.tvScore);
            acc     = v.findViewById(R.id.tvAcc);
            details = v.findViewById(R.id.tvDetails);
            time    = v.findViewById(R.id.tvTime);
        }
    }
}
