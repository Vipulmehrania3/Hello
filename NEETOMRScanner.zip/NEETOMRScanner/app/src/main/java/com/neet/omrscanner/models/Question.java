package com.neet.omrscanner.models;
import java.io.Serializable;

public class Question implements Serializable {
    private int questionNumber;
    private int correctAnswer;   // 1-4
    private int userAnswer;      // 0=unattempted

    public Question(int questionNumber, int correctAnswer) {
        this.questionNumber = questionNumber;
        this.correctAnswer  = correctAnswer;
        this.userAnswer     = 0;
    }

    public int  getQuestionNumber()          { return questionNumber; }
    public int  getCorrectAnswer()           { return correctAnswer; }
    public int  getUserAnswer()              { return userAnswer; }
    public void setUserAnswer(int a)         { this.userAnswer = a; }
    public boolean isCorrect()               { return userAnswer == correctAnswer; }
    public boolean isUnattempted()           { return userAnswer == 0; }
    public boolean isWrong()                 { return userAnswer != 0 && userAnswer != correctAnswer; }
}
