package com.neet.omrscanner.utils;

import android.graphics.Bitmap;
import android.util.Log;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.neet.omrscanner.models.Question;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AnswerKeyParser {

    public interface ParseCallback {
        void onSuccess(List<Question> questions);
        void onFailure(String error);
    }

    public static void parseFromBitmap(Bitmap bitmap, ParseCallback callback) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
            .addOnSuccessListener(text -> {
                List<Question> qs = extract(text);
                if (qs.isEmpty())
                    callback.onFailure("Could not detect answer key.\nMake sure the image clearly shows the Que./Ans. table.");
                else
                    callback.onSuccess(qs);
            })
            .addOnFailureListener(e -> callback.onFailure("OCR error: " + e.getMessage()));
    }

    private static List<Question> extract(Text visionText) {
        String fullText = visionText.getText();
        Log.d("Parser", "OCR: " + fullText);
        String[] lines = fullText.split("\n");

        int queIdx = -1, ansIdx = -1;
        for (int i = 0; i < lines.length; i++) {
            String lo = lines[i].toLowerCase().trim();
            if (lo.startsWith("que") || lo.contains("que."))  { queIdx = i; }
            else if ((lo.startsWith("ans") || lo.contains("ans.")) && queIdx != -1) { ansIdx = i; break; }
        }

        List<Question> qs = new ArrayList<>();

        if (queIdx != -1 && ansIdx != -1) {
            List<Integer> qNums  = numbers(lines[queIdx]);
            List<Integer> aNums  = numbers(lines[ansIdx]);
            int count = Math.min(qNums.size(), aNums.size());
            for (int i = 0; i < count; i++) {
                int a = aNums.get(i);
                if (a >= 1 && a <= 4) qs.add(new Question(qNums.get(i), a));
            }
        }

        // Fallback: find a line of all-1-to-4 numbers (answer row)
        if (qs.isEmpty()) {
            for (String line : lines) {
                List<Integer> nums = numbers(line);
                if (nums.size() < 5) continue;
                boolean valid = nums.stream().allMatch(n -> n >= 1 && n <= 4);
                if (valid) {
                    for (int i = 0; i < nums.size(); i++)
                        qs.add(new Question(i + 1, nums.get(i)));
                    break;
                }
            }
        }
        return qs;
    }

    private static List<Integer> numbers(String s) {
        List<Integer> list = new ArrayList<>();
        Matcher m = Pattern.compile("\\d+").matcher(s);
        while (m.find()) list.add(Integer.parseInt(m.group()));
        return list;
    }
}
